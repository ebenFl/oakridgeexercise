from flask import request, make_response, jsonify, abort
from flask_restful import Resource
from models.batch_job import batchJob
from dateutil.parser import *
from sqlalchemy import func
import re

def cleanTime(t):
    """
    This function is used to clean/fix ISO 8601 timestamps provided
    in the url query params. When passed through as query param the '+'
    character is replaced with a ' ' which causes the datutil parser
    to complain, this function fixes that and removes any quotations 
    as well
    """
    t = t.replace("'","")
    pattern = re.compile(r"^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2} [0-9]{2}:[0-9]{2}$")
    match = pattern.match(t)
    if match: # matched pattern for ISO 8601 time format with '+' replace with ' '
        t = t.replace(" ","+")
    return t

class batchJobs(Resource):
    def get(self):
        responseData = {
            "links": {
                "self": request.url
            },
            "jobs": []
        }

        # build the query
        jobs = batchJob.query

        args = request.args

        args = args.to_dict()

        if args.get('filter[submitted_after]'):
            time = args['filter[submitted_after]']
            time = cleanTime(time)
            try:
                parsed_time = parse(time)
            except ParserError:
                abort(400, "Inproper time string supplied for filter[submitted_after]")
            jobs = jobs.filter(func.DateTime(batchJob.submitted_at) >= func.DateTime(parsed_time.__str__()))

        if args.get('filter[submitted_before]'):
            time = args['filter[submitted_before]']
            time = cleanTime(time)
            try:
                parsed_time = parse(time)
            except ParserError:
                abort(400, "Inproper time string supplied for filter[submitted_before]")
            jobs = jobs.filter(func.DateTime(batchJob.submitted_at) <= func.DateTime(parsed_time.__str__()))

        # if the timezones are neither both timezone

        if args.get('filter[min_nodes]'):
            min_nodes = args['filter[min_nodes]']
            try:
                min_nodes = int(min_nodes)
            except ValueError:
                abort(400, "filter[min_nodes] must be an integer")
            jobs = jobs.filter(batchJob.nodes_used >= min_nodes)

        if args.get('filter[max_nodes]'):
            max_nodes = args['filter[max_nodes]']
            try:
                max_nodes = int(max_nodes)
            except ValueError:
                abort(400, "filter[max_nodes] must be an integer")
            jobs = jobs.filter(batchJob.nodes_used <= max_nodes)

        jobs = jobs.all()
        for j in jobs:
            responseData['jobs'].append({
                "type": "batch_jobs",
                "id": j.id,
                "attributes": {
                    'batch_number': j.batch_number,
                    'submitted_at': j.submitted_at,
                    'nodes_used': j.nodes_used
                }
            })

        resp = make_response(responseData, 200)
        return resp
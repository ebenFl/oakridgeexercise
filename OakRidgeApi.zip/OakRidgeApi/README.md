# Coding Exercise Submission

---

<font size="5">
    Hello, this is my submission for the coding exercise you have provided.
    For my submission I decided to use Flask and Python with a simple SQLite database.
    The project fulfills the requirements provided though I would like to inform you of 
    a couple small liberties I took.
</font>

---

<font size="5">
    For the actual data everything is present minus entries in the .csv that were missing fields.
    All of the filters listed in the problem description are present, though I have extended the
    filter[submitted_before] and filter[submitted_after] to try and accept any valid date format. For example
</font>
<p><br></p>

> http://localhost:5000/batch_jobs?filter[submitted_after]=2018-03-02

<font size="5">
    Would give you jobs submitted on or after 2018-03-02. 
</font>
<p><br></p>

```
"jobs": [
    {
      "attributes": {
        "batch_number": 401,
        "nodes_used": 12182,
        "submitted_at": "2018-03-02T00:00:01+00:00"
      },
      "id": 399,
      "type": "batch_jobs"
    },
    {
      "attributes": {
        "batch_number": 402,
        "nodes_used": 1554,
        "submitted_at": "2018-03-02T00:07:13+00:00"
      },
      "id": 400,
      "type": "batch_jobs"
    },
    ...
```


<font size="5">
    While this extension makes it nice to easily play around with the api there can be issues with inclusive ranges ([submitted_after, submitted_before]) for some date formats so please just stick to the ISO 8601 format when testing correctness as it works as intended.
</font>

---

<font size="5">
    In terms of what could be improved I think a different choice of database would be the first step.
    SQLite doesn't have a datetime column type so working with dates can be confusing and causes some inconsistencies with other accepted date formats aside from ISO 8601. I could just drop the date format extension by doing a regex check on the filters for certain time formats but I've decided to just leave it as is. Also my project
    tears down and sets up the database on each run for simplicity which is fine for this sized dataset but if the dataset was large with multiple tables this would be slow. This would also need to be changed if we wanted to let users add new data. If the project ever wanted to deal with more data and persistent changes a more complete rdbms might be of interest.
</font>

---

#Setup

<font size="5">
    For these setup instructions I'm going to assume that you are on Windows for the commands I provide. However, the process will be the same for other operating systems. To run the api you will need a python version >= 3.7, I have python 3.11 on my system and if you don't have python you can get it here. Make sure to get the recommended installer.
</font>

>https://www.python.org/downloads/release/python-3110/

<font size="5">
    Run through the default installation, this will include pip. Make sure to click the box that adds python to your PATH environment so you can run the following commands in the terminal to check that they are installed.
</font>


*python --version* 
---

*pip --version*
---

<font size="5">
    With Python and pip installed navigate to the base directory of the project. To run the api your going to need flask and some other libraries. They are listed in the requirements.txt file.
    To install them you can run the following command.
</font>


*pip install -r requirements.txt*
---

<font size="5">
    Now with everything installed you can run the api by executing
</font>


*python app.py*
---

<font size="5">
    The api will be hosted on localhost and the initial program output will tell you exactly where. To turn
    the api off type CTRL^C. I have also provided two very basic tests located in <br><br> <i>project_tests/test_endpoint.py </i><br>
    <br>
    These can be executed by running the following command in the terminal
</font>

*pytest*
---

<font size="5">
    Thank you for taking the time to look at my submission and have a nice day.
</font>
from flask import Flask
from flask_restful import Api

from resources.batch_jobs import batchJobs
from utils.build_db import populate_db

def create_app():
    """
    Factory function for the flask application
    """
    app = Flask(__name__)
    api = Api(app)
    app.config['SQLALCHEMY_DATABASE_URI'] = "sqlite:///batch_jobs.db"
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    
    with app.app_context():
        # building the database is fast and the database doesn't need to
        # hold persistent changes so its easier to 
        # just setup the database again quickly each time the api is run
        from db import db
        db.init_app(app)
        db.drop_all()
        db.create_all()
        populate_db(db)

    api.add_resource(batchJobs, '/batch_jobs')
    return app, api


if __name__ == "__main__":
    app, api = create_app()
    app.run(debug=True)
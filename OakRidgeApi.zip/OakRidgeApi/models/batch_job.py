from db import db

class batchJob(db.Model):
    __tablename__ = "batchJobs"
    id = db.Column(db.Integer, primary_key=True)
    batch_number = db.Column(db.Integer, unique=True, nullable=False)
    submitted_at = db.Column(db.String(50), nullable=False)
    nodes_used = db.Column(db.Integer, nullable=False)

    def __init__(self, b_number, subm_at, n_used):
        self.batch_number = b_number
        self.submitted_at = subm_at
        self.nodes_used = n_used
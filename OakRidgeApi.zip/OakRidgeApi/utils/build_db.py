from dateutil.parser import *
from models.batch_job import batchJob 

def populate_db(database):
    """
    Reads the csv file and populates the database
    database should be a sql alchemy object thats
    hooked into the flask project
    """
    print("Populating database with batch job information...")
    with open('data/example_batch_records.csv') as csv_file:
        for line in csv_file:
            batch_num, time, nodes = line.split(',')
            nodes = nodes.replace("\n","")
            if("" in [batch_num, time, nodes]):
                continue
            if (batch_num == "ï»¿1"): # utf-8-bom encoding adds strange characters to start of file
                batch_num = "1"
            entry = batchJob(int(batch_num), time, int(nodes))
            database.session.add(entry)
    database.session.commit()
    print("Finished populating database...")
import pytest
import json
from dateutil.parser import *
from models.batch_job import batchJob
import app as factory

"""
A couple of tests I wrote to help double check that things are working
not an extensive set of tests by any means
"""

@pytest.fixture()
def app():
    app, api = factory.create_app()
    app.config.update({
        "TESTING": True,
    })
    # clean up / reset resources here
    
    #
    yield app


@pytest.fixture()
def client(app):
    return app.test_client()


def test_filters(client):
    """
        Applies all of the available filters and ensures that 
        all the filters are being applied correctly together
    """
    payload = {
        'filter[submitted_after]': '2018-02-28T06:21:37+00:00',
        'filter[submitted_before]': '2018-03-02T09:43:13+00:00',
        'filter[min_nodes]': 1500,
        'filter[max_nodes]': 10000
    }
    response = client.get('/batch_jobs', query_string=payload)
    response_data = json.loads(response.get_data(as_text=True))

    assert response.status_code == 200

    # build datetime.datetime object for submitted_before/after

    submitted_after = parse(payload['filter[submitted_after]'])
    submitted_before = parse(payload['filter[submitted_before]'])

    for job in response_data['jobs']:
        assert submitted_after <= parse(job['attributes']['submitted_at'])
        assert submitted_before >= parse(job['attributes']['submitted_at'])
        assert job['attributes']['nodes_used'] <= payload['filter[max_nodes]']
        assert job['attributes']['nodes_used'] >= payload['filter[min_nodes]']


def test_against_bad_input(client):
    """
        Test against some bad input and make sure that the endpoint
        gives back a 400 response code, not extensive by any means
    """
    response = client.get('/batch_jobs', query_string={'filter[min_nodes]': 'IamAString!'})
    assert response.status_code == 400

    response = client.get('/batch_jobs', query_string={'filter[submitted_after]': '2019-10-21 :15:02'})
    assert response.status_code == 400

    response = client.get('/batch_jobs', query_string={'filter[submitted_after]': '00000'})
    assert response.status_code == 400

    response = client.get('/batch_jobs', query_string={'filter[submitted_before]': ' a '})
    assert response.status_code == 400

